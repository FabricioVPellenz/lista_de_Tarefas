package com.fabriciovp.lista_de_tarefas

data class Task(
    val title: String,
    val description: String,
    val date: String,
    val time: String,
    val taskId: Int = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Task

        if (taskId != other.taskId) return false

        return true
    }

    override fun hashCode(): Int {
        return taskId
    }
}
