package com.fabriciovp.lista_de_tarefas

import com.google.android.material.textfield.TextInputLayout
import java.text.SimpleDateFormat
import java.util.*

private val local = Locale("pt", "BR")

fun Date.format() : String {
    return SimpleDateFormat("dd.MM.yyyy", local).format(this)
 }

var TextInputLayout.text : String
    get() = editText?.text?.toString() ?: ""
    set(valor) {
        editText?.setText(valor)
    }