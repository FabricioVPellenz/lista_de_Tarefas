package com.fabriciovp.lista_de_tarefas

object TaskDataBase {
    private val list = arrayListOf<Task>()

    fun getList() = list.toList()

    fun addNewTask(task: Task) {
        if (task.taskId == 0) {
            list.add(task.copy(taskId = list.size + 1))
        } else {
            list.remove(task)
            list.add(task)
        }
    }

    fun findById(taskId: Int) = list.find { it.taskId == taskId }

    fun deleteTask(task:Task) {
        list.remove(task)
    }
}
