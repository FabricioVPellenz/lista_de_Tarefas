package com.fabriciovp.lista_de_tarefas

import android.app.Activity
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.fabriciovp.lista_de_tarefas.databinding.ActivityAddtaskBinding
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import java.util.*

class AddTaskActivity : AppCompatActivity() {

    private lateinit var layoutAddTask: ActivityAddtaskBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        layoutAddTask = ActivityAddtaskBinding.inflate(layoutInflater)
        setContentView(layoutAddTask.root)

        if (intent.hasExtra(TASK_ID)) {
            val taskId = intent.getIntExtra( TASK_ID, 0)
            TaskDataBase.findById(taskId)?.let {
                layoutAddTask.tilTitle.text = it.title
                layoutAddTask.tilDescription.text = it.description
                layoutAddTask.tilDate.text = it.date
                layoutAddTask.tilTime.text = it.time
            }
        }

        //inserInputListeners()
        insertButtonListeners()
    }

/*    private fun inserInputListeners() {
        layoutAddTask.tilDate.editText?.setOnClickListener {
            val dateSelect = MaterialDatePicker.Builder.datePicker().build()
            dateSelect.addOnPositiveButtonClickListener {
                val hourCircle = TimeZone.getDefault()
                val adjustDate = hourCircle.getOffset(Date().time) * -1
                layoutAddTask.tilDate.text = Date(it + adjustDate).format()
            }
            dateSelect.show(supportFragmentManager, "DATE_PICKER_TAG")
        }
        layoutAddTask.tilTime.editText?.setOnClickListener {
            val timeSelect = MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_24H)
                .build()
            timeSelect.addOnPositiveButtonClickListener {
                val timeHour = if (timeSelect.hour < 10) "0${timeSelect.hour}" else timeSelect.hour
                val timeMinute = if (timeSelect.minute < 10) "0${timeSelect.minute}" else timeSelect.minute
                layoutAddTask.tilTime.text = "$timeHour:$timeMinute"
            }
            timeSelect.show(supportFragmentManager, null)
        }
    }
*/

    private fun insertButtonListeners() {
        layoutAddTask.bAdd.setOnClickListener {
                val newTask = Task(
                    title = layoutAddTask.tilTitle.text,
                    description = layoutAddTask.tilDescription.text,
                    date = layoutAddTask.tilDate.text,
                    time = layoutAddTask.tilTime.text,
                    taskId = intent.getIntExtra(TASK_ID, 0)
                )
                TaskDataBase.addNewTask(newTask)
                setResult(Activity.RESULT_OK)
                finish()
        }
        layoutAddTask.bCancel.setOnClickListener {
            finish()
        }

    }

    companion object {
        const val TASK_ID = "task_id"
    }
}