/*
Infelizmente não consegui desenvolver o projeto.
Inclusive a base do projeto ensinada pelo professor para mim não funcionou.
Há muito detalhe, talvez não captei alguma coisa e por isso não funcionou integralmente.
Nâo sou dev profissional, trabalho em outra função 8h por dia e estou fazendo um curso tecnólogo que termina este ano.
Não consegui estudar para conseguir aprender. Muito difícil conpreender a lógica do Kotlin para mim.
Sei um pouco de programação, mas quase nada em POO, a quantidade de funções existentes e conexões entre elas exije muita
leitura e treino, o que não pude ter nesses 75 dias.
Mas foi um excelente aprendizado.
Fiquei apenas muito decepcionado por não conseguir entregar um projeto de qualidade.
Nem mesmo funcionando corretamente ele não está. Não consegui.
*/
package com.fabriciovp.lista_de_tarefas

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.fabriciovp.lista_de_tarefas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var layoutMainActivity: ActivityMainBinding
    private val adapter by lazy { TaskListAdapter() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        layoutMainActivity = ActivityMainBinding.inflate(layoutInflater)
        setContentView(layoutMainActivity.root)

        layoutMainActivity.rvTasklist.adapter = adapter

        updateList()

        insertListeners()
        // data store
        // room
    }

    private fun insertListeners(){
          layoutMainActivity.bAddTask.setOnClickListener {
              startActivityForResult(Intent(this, AddTaskActivity::class.java), CREATE_NEW_TASK)
          }

          adapter.listenerEdit = {

              val intent = Intent(this,AddTaskActivity::class.java)
              intent.putExtra(AddTaskActivity.TASK_ID, it.taskId)
              startActivityForResult(intent, CREATE_NEW_TASK)
          }

          adapter.listenerDelete = {
              TaskDataBase.deleteTask(it)
              updateList()
          }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_NEW_TASK && resultCode == Activity.RESULT_OK) {
            layoutMainActivity.rvTasklist.adapter = adapter
            adapter.submitList(TaskDataBase.getList())
        }
    }

    private fun updateList() {
        val list =TaskDataBase.getList()
        layoutMainActivity.noTasks.tvNoTask.visibility=
            if (list.isEmpty()) View.VISIBLE else View.GONE
        adapter.submitList(TaskDataBase.getList())
    }

    companion object {
        private const val CREATE_NEW_TASK = 100
    }
}