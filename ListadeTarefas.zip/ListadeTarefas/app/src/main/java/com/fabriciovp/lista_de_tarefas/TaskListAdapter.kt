package com.fabriciovp.lista_de_tarefas

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.widget.PopupMenu
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fabriciovp.lista_de_tarefas.databinding.TaskItemBinding

class TaskListAdapter: ListAdapter<Task, TaskListAdapter.TaskViewHolder>(DiffCallback()) {

    var listenerEdit : (Task) -> Unit = {}
    var listenerDelete : (Task) -> Unit = {}

    inner class TaskViewHolder(
        private val layoutTaskItem: TaskItemBinding
        ) : RecyclerView.ViewHolder(layoutTaskItem.root) {

        fun bind(item: Task) {
            layoutTaskItem.tvItemTitle.text = item.title
            layoutTaskItem.tvItemDescription.text = item.description
            layoutTaskItem.tvItemTime.text = "${item.date} - ${item.time}"
            layoutTaskItem.civMenu.setOnClickListener {
                showMenu(item)
            }
        }

        private fun showMenu(item: Task) {
            val civMenu = layoutTaskItem.civMenu
            val menu = PopupMenu(civMenu.context, civMenu)
            menu.menuInflater.inflate(R.menu.task_menu, menu.menu)
            menu.setOnMenuItemClickListener {
                when (it.itemId) {
                    R.id.mi_edit -> listenerEdit(item)
                    R.id.mi_delete -> listenerDelete(item)
                }
                return@setOnMenuItemClickListener true
            }
            menu.show()
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = LayoutInflater.from(parent.context)
        val layoutTaskItem = TaskItemBinding.inflate(binding, parent, false)
        return TaskViewHolder(layoutTaskItem)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

}

class DiffCallback : DiffUtil.ItemCallback<Task>() {
    override fun areItemsTheSame(oldItem: Task, newItem: Task): Boolean = oldItem == newItem
    override fun areContentsTheSame(oldItem: Task, newItem: Task): Boolean = oldItem.taskId == newItem.taskId
}
